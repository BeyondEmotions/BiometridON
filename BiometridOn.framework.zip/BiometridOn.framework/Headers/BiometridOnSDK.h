//
//  BiometridOnSDK.h
//  BiometridOn
//
//  Created by Tiago Carvalho on 17/01/2018.
//  Copyright © 2018 Tiago Carvalho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BiometridOnSDK : NSObject

+ (instancetype)sharedInstance;

/*!
 *  @discussion BiometridOn SDK initialization with credentials.
 *  @param key Application client key.
 *  @param secret Application client secret.
 *  @param flowId Application flow identifier.
 *  @param serverUrl Application server url.
 *  @warning init must be called at least once by the application before invoking any SDK operations.
 */
- (void)initWithKey:(NSString *)key withSecret:(NSString *)secret withFlowId:(NSString *)flowId andServerUrl:(NSString *)serverUrl andCallback:(void(^)(NSDictionary* response, NSError *error))completion;


@end
